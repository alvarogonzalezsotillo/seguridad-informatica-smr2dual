﻿EAR   -- Entorno para el Análisis de Riesgos
PILAR -- Herramienta de Análisis y Gestión de Riesgos

El paquete PilarBasic proporciona herramientas para:

      * gestión cualitativa de riesgos: análisis y tratamiento

Para utilizar EAR/PILAR se requiere un runtime de Java 2,

       JRE

que se puede descargar de

       http://java.sun.com/j2se/

