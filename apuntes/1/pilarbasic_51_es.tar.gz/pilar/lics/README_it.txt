Licenze d'uso
-------------
Copiare in questa cartella la licenza d'uso ricevuta.

Le licenze sono file con estensione ".lic".

La presenza di una licenza d� diritto a modificare progetti di
analisi dei rischi.
In ogni caso, anche se non si dispone di una licenza, � comunque
possibile accedere ai progetti in modalit� presentazione (sola lettura).
