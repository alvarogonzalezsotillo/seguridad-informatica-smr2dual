Permis d'utilisateur 
--------------------
S'il vous pla�t, 
la copie dans cet annuaire le permis d'utilisateur vous avez re�u. 

Les permis sont des dossiers avec l'extension ".lic". 

Le permis accorde des droits pour �diter les projets d'analyse de risque.
N�anmoins, aucun permis est exig� acc�der � des projets 
dans le mode non modifiable.
