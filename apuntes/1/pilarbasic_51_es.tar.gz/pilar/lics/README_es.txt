Licencias de utilizaci�n
------------------------
Copie en este directorio la licencia de uso recibida.

Las licencias son ficheros con extensi�n ".lic".

La existencia de una licencia da derechos para editar proyectos de
an�lisis de riesgos.
No obstante, aunque no disponga de una licencia,
siempre prodr� acceder a los proyectos en modo presentaci�n (read-only).
