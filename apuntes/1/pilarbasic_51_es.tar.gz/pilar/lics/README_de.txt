User license
------------
Please, copy into this directory the user license you received.

Licenses are files with extension ".lic".

License grants rights to edit risk analysis projects.
Nevertheless, no license is required to access projects in read-only mode.
