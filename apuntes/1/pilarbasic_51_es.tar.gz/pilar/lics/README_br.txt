Licen�a de usu�rio 
------------------
Por favor, copie para este diret�rio o licen�a de usu�rio que voc� recebeu.

Licen�as s�o arquivos com extens�o ".lic".

A licen�a concede direitos de editar projetos de an�lise de risco.
No entanto, n�o � necess�ria licen�a para acessar projetos em modo somente leitura.